document.addEventListener("DOMContentLoaded", function() {
    const nextPageLink = document.getElementById("nextPageLink");
    const prologue = document.getElementById("prologue");
    const cardsContainer = document.getElementById("cards-container");
    const contactForm = document.getElementById("contactForm");
    const newsletterForm = document.getElementById("newsletterForm");

    newsletterForm.addEventListener("submit", function(event) {
        event.preventDefault();
        alert("Thank you for subscribing to our newsletter!");
        newsletterForm.reset();
    });


    contactForm.addEventListener("submit", function(event) {
        event.preventDefault();
        alert("Thank you for reaching out! I'll get back to you soon.");
        contactForm.reset();
    });

    nextPageLink.addEventListener("click", function() {
        prologue.style.display = "none";
        cardsContainer.style.display = "grid";
        cardsContainer.classList.add("fade-in");
    });
});
