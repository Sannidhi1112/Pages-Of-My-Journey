import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TabsContent } from "@/components/ui/tabs";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Newsletter, Contact } from "@shared/schema";
import { Loader2, User, Mail, ArrowLeft, LogOut } from "lucide-react";
import AdminLayout from "@/components/admin/layout";

export default function AdminDashboard() {
  const { user, logoutMutation } = useAuth();
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  // Get newsletter subscriptions count
  const { data: newsletterSubscriptions, isLoading: isLoadingNewsletters } = useQuery<Newsletter[]>({
    queryKey: ["/api/admin/newsletter-subscriptions"],
  });
  
  // Get contact submissions count
  const { data: contactSubmissions, isLoading: isLoadingContacts } = useQuery<Contact[]>({
    queryKey: ["/api/admin/contact-submissions"],
  });
  
  const isLoading = isLoadingNewsletters || isLoadingContacts;
  
  return (
    <AdminLayout>
      <TabsContent value="overview" className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="outline" size="sm">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Website
              </Button>
            </Link>
            <Button variant="outline" size="sm" onClick={handleLogout}>
              <LogOut className="mr-2 h-4 w-4" />
              Logout
            </Button>
          </div>
        </div>
        
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Newsletter Subscribers
              </CardTitle>
              <User className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              {isLoadingNewsletters ? (
                <div className="flex items-center space-x-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <p className="text-sm text-muted-foreground">Loading...</p>
                </div>
              ) : (
                <>
                  <div className="text-2xl font-bold">
                    {newsletterSubscriptions?.length || 0}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Total newsletter subscribers
                  </p>
                </>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Contact Submissions
              </CardTitle>
              <Mail className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              {isLoadingContacts ? (
                <div className="flex items-center space-x-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <p className="text-sm text-muted-foreground">Loading...</p>
                </div>
              ) : (
                <>
                  <div className="text-2xl font-bold">
                    {contactSubmissions?.length || 0}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Total contact form submissions
                  </p>
                </>
              )}
            </CardContent>
          </Card>
        </div>
        
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <Card className="col-span-3">
            <CardHeader>
              <CardTitle>Welcome to Admin Dashboard</CardTitle>
              <CardDescription>
                Manage and monitor your website from this central dashboard.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>
                Welcome, {user?.username}! From this dashboard, you can:
              </p>
              <ul className="list-disc pl-5 space-y-2">
                <li>View and manage newsletter subscribers</li>
                <li>Track and respond to contact form submissions</li>
                <li>Monitor website activity</li>
              </ul>
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Link href="/admin/newsletters">
                  <Button>View Newsletter Subscribers</Button>
                </Link>
                <Link href="/admin/contacts">
                  <Button variant="outline">View Contact Submissions</Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </TabsContent>
    </AdminLayout>
  );
}