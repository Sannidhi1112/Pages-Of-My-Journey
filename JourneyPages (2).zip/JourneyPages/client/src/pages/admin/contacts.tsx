import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Contact } from "@shared/schema";
import { format } from "date-fns";
import { TabsContent } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Loader2, Eye } from "lucide-react";
import AdminLayout from "@/components/admin/layout";

export default function ContactSubmissions() {
  const [selectedSubmission, setSelectedSubmission] = useState<Contact | null>(null);
  
  const { data: contacts, isLoading } = useQuery<Contact[]>({
    queryKey: ["/api/admin/contact-submissions"],
  });

  return (
    <AdminLayout>
      <TabsContent value="contacts" className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-3xl font-bold tracking-tight">Contact Submissions</h2>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>All Submissions</CardTitle>
            <CardDescription>
              View and manage contact form submissions from website visitors.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : contacts && contacts.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Message Preview</TableHead>
                    <TableHead>Date Submitted</TableHead>
                    <TableHead className="w-[100px]">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {contacts.map((submission) => (
                    <TableRow key={submission.id}>
                      <TableCell>{submission.name}</TableCell>
                      <TableCell>{submission.email}</TableCell>
                      <TableCell>{submission.message.substring(0, 30)}...</TableCell>
                      <TableCell>
                        {format(new Date(submission.createdAt), "PPP")}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setSelectedSubmission(submission)}
                        >
                          <Eye className="h-4 w-4" />
                          <span className="sr-only">View</span>
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                No contact submissions found.
              </div>
            )}
          </CardContent>
        </Card>
        
        <Dialog open={!!selectedSubmission} onOpenChange={(open) => !open && setSelectedSubmission(null)}>
          {selectedSubmission && (
            <DialogContent className="sm:max-w-lg">
              <DialogHeader>
                <DialogTitle>Contact Submission</DialogTitle>
                <DialogDescription>
                  Submitted on {format(new Date(selectedSubmission.createdAt), "PPP 'at' p")}
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="grid grid-cols-4 gap-4">
                  <div className="col-span-1 font-medium">Name:</div>
                  <div className="col-span-3">{selectedSubmission.name}</div>
                </div>
                <div className="grid grid-cols-4 gap-4">
                  <div className="col-span-1 font-medium">Email:</div>
                  <div className="col-span-3">{selectedSubmission.email}</div>
                </div>

                <div>
                  <div className="font-medium mb-2">Message:</div>
                  <div className="whitespace-pre-wrap border p-3 rounded-md bg-muted/50">
                    {selectedSubmission.message}
                  </div>
                </div>
              </div>
            </DialogContent>
          )}
        </Dialog>
      </TabsContent>
    </AdminLayout>
  );
}