import { useQuery } from "@tanstack/react-query";
import { Newsletter } from "@shared/schema";
import { format } from "date-fns";
import { TabsContent } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Loader2 } from "lucide-react";
import AdminLayout from "@/components/admin/layout";

export default function NewsletterSubscribers() {
  const { data: newsletters, isLoading } = useQuery<Newsletter[]>({
    queryKey: ["/api/admin/newsletter-subscriptions"],
  });

  return (
    <AdminLayout>
      <TabsContent value="newsletters" className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-3xl font-bold tracking-tight">Newsletter Subscribers</h2>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>All Subscribers</CardTitle>
            <CardDescription>
              Manage your newsletter subscribers from this panel.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : newsletters && newsletters.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Email</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Date Subscribed</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {newsletters.map((subscriber) => (
                    <TableRow key={subscriber.id}>
                      <TableCell>{subscriber.email}</TableCell>
                      <TableCell>Newsletter Subscriber</TableCell>
                      <TableCell>
                        {format(new Date(subscriber.createdAt), "PPP")}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                No subscribers found.
              </div>
            )}
          </CardContent>
        </Card>
      </TabsContent>
    </AdminLayout>
  );
}