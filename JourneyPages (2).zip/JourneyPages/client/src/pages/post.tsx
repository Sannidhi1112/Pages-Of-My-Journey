import { useParams, Link, useLocation } from "wouter";
import { ArrowLeft, Twitter, Facebook, Youtube } from "lucide-react";
import Comment from "@/components/blog/comment";
import PostCommentForm from "@/components/common/post-comment-form";
import { usePost, useCategories, useComments, getCategoryName } from "@/lib/data";
import { formatDistance } from "date-fns";

const Post = () => {
  const { slug } = useParams();
  const [, navigate] = useLocation();
  
  const { data: post, isLoading: postLoading, error } = usePost(slug || "");
  const { data: categories, isLoading: categoriesLoading } = useCategories();
  const { data: comments, isLoading: commentsLoading } = useComments(post?.id);
  
  if (error) {
    navigate("/not-found");
    return null;
  }
  
  if (postLoading || categoriesLoading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="text-center py-16">Loading post...</div>
      </div>
    );
  }
  
  if (!post) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="text-center py-16">Post not found</div>
      </div>
    );
  }
  
  const categoryName = getCategoryName(categories, post.categoryId);
  const formattedDate = post.createdAt 
    ? formatDistance(new Date(post.createdAt), new Date(), { addSuffix: true })
    : "Unknown date";
  
  // Define related posts (in real app, would use actual related content)
  const relatedPosts = [
    {
      id: 1,
      title: "5 Quick Morning Workouts Under 10 Minutes",
      date: "April 2, 2023",
      image: "https://images.unsplash.com/photo-1526506118085-60ce8714f8c5?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    },
    {
      id: 2,
      title: "How to Build Healthy Morning Habits",
      date: "March 15, 2023",
      image: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    },
    {
      id: 3,
      title: "Nutrition Tips for Morning Workouts",
      date: "May 8, 2023",
      image: "https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    }
  ];
  
  return (
    <div className="max-w-4xl mx-auto px-4 py-8 fade-in">
      <Link href="/blog">
        <a className="inline-flex items-center text-[rgb(63,9,114)] hover:text-[rgb(74,6,139)] mb-6 transition duration-300">
          <ArrowLeft className="h-5 w-5 mr-1" />
          Back to Blog
        </a>
      </Link>
      
      <div className="border-2 border-[rgb(62,62,76)] shadow-[8px_8px_2px_0_rgb(87,77,131)] rounded-lg overflow-hidden">
        {post.coverImage && (
          <img 
            src={post.coverImage} 
            alt={`Cover image for ${post.title}`} 
            className="w-full h-80 object-cover"
          />
        )}
        
        <div className="p-8">
          <div className="flex items-center justify-between mb-4">
            <span className="inline-block bg-[#c5c5e2] px-3 py-1 rounded-full text-sm text-[rgb(63,9,114)]">
              {categoryName}
            </span>
            <span className="text-gray-500 text-sm">{formattedDate}</span>
          </div>
          
          <h1 className="text-3xl font-bold text-[rgb(74,6,139)] mb-6">{post.title}</h1>
          
          <div 
            className="prose max-w-none text-gray-600"
            dangerouslySetInnerHTML={{ __html: post.content }}
          />
          
          <div className="border-t border-[rgb(62,62,76)] mt-8 pt-6">
            <h3 className="text-lg font-bold text-[rgb(74,6,139)] mb-3">Share this post</h3>
            <div className="flex space-x-4">
              <a href="#" className="text-[rgb(63,9,114)] hover:text-[rgb(74,6,139)] transition duration-300">
                <Twitter className="h-6 w-6" />
              </a>
              <a href="#" className="text-[rgb(63,9,114)] hover:text-[rgb(74,6,139)] transition duration-300">
                <Facebook className="h-6 w-6" />
              </a>
              <a href="#" className="text-[rgb(63,9,114)] hover:text-[rgb(74,6,139)] transition duration-300">
                <Youtube className="h-6 w-6" />
              </a>
            </div>
          </div>
        </div>
      </div>
      
      {/* Related Posts */}
      <div className="mt-12">
        <h3 className="text-xl font-bold text-[rgb(74,6,139)] mb-6">You Might Also Enjoy</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {relatedPosts.map(relatedPost => (
            <div 
              key={relatedPost.id}
              className="border-2 border-[rgb(62,62,76)] rounded-lg overflow-hidden shadow-md hover:shadow-[8px_8px_2px_0_rgb(87,77,131)] transition duration-300"
            >
              <img 
                src={relatedPost.image} 
                alt={`Related post image for ${relatedPost.title}`}
                className="w-full h-40 object-cover"
              />
              <div className="p-4">
                <h4 className="font-semibold text-[rgb(74,6,139)]">{relatedPost.title}</h4>
                <p className="text-gray-500 text-sm mt-2">{relatedPost.date}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Comments Section */}
      <div className="mt-12">
        <h3 className="text-xl font-bold text-[rgb(74,6,139)] mb-6">
          Comments ({commentsLoading ? "..." : comments?.length || 0})
        </h3>
        
        {commentsLoading ? (
          <div className="text-center py-4">Loading comments...</div>
        ) : comments && comments.length > 0 ? (
          comments.map(comment => (
            <Comment key={comment.id} comment={comment} />
          ))
        ) : (
          <div className="text-center py-4 mb-4 border-2 border-[rgb(62,62,76)] rounded-lg">
            <p className="text-gray-600 p-4">No comments yet. Be the first to comment!</p>
          </div>
        )}
        
        {/* Comment Form */}
        {post.id && <PostCommentForm postId={post.id} />}
      </div>
    </div>
  );
};

export default Post;
