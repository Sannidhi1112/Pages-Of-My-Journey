import WorkoutCategories from "@/components/fitness/workout-categories";
import YogaSection from "@/components/fitness/yoga-section";
import WorkoutSection from "@/components/fitness/workout-section";
import "@/styles/fitness.css";

const Fitness = () => {

  // Pilates channels data
  const pilatesChannels = [
    { name: "MoveWithNicole", url: "https://www.youtube.com/@MoveWithNicole" },
    { name: "MoveWithAgnes", url: "https://www.youtube.com/@movewithagnes" },
    { name: "LillySabri", url: "https://www.youtube.com/@LillySabri" },
    { name: "Blogilates", url: "https://www.youtube.com/@blogilates" }
  ];

  // Dance channels data
  const danceChannels = [
    { name: "WorkoutWithSabah", url: "https://www.youtube.com/@workoutwithsabah" },
    { name: "DanceWithDeepti", url: "https://www.youtube.com/@DanceWithDeepti" },
    { name: "MadFit", url: "https://www.youtube.com/playlist?list=PLN99XDk2SYr7YFHIVmTffejyRZliMGGIM" },
    { name: "GrowWithJo", url: "https://www.youtube.com/playlist?list=PLG9XM5PzrT1eUy_R9xkiVfs9GNvwNS3Xz" }
  ];

  // HIIT channels data
  const hiitChannels = [
    { name: "cult.official", url: "https://www.youtube.com/@cult.official" },
    { name: "MadFit", url: "https://www.youtube.com/@MadFit/featured" },
    { name: "growingannanas", url: "https://www.youtube.com/@growingannanas" },
    { name: "JuiceandToya", url: "https://www.youtube.com/@JuiceandToya" }
  ];
  
  return (
    <div className="max-w-7xl mx-auto px-4 py-8 fade-in">
      <div className="text-center mb-12">
        <h1 className="text-3xl font-bold text-[rgb(74,6,139)] mb-4">Fitness Journey</h1>
        <p className="text-gray-600 max-w-3xl mx-auto">
          Discover my personal fitness journey, workout routines, nutrition tips, and how I overcame challenges to build a sustainable fitness habit.
        </p>
      </div>
      
      {/* Hero Image */}
      <div className="rounded-lg overflow-hidden mb-12 shadow-[8px_8px_2px_0_rgb(87,77,131)] border-2 border-[rgb(62,62,76)]">
        <img 
          src="https://images.unsplash.com/photo-1517836357463-d25dfeac3438?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80" 
          alt="Fitness Journey"
          className="w-full h-96 object-cover"
        />
      </div>
      
      {/* Fitness Content */}
      <div className="mb-12">
        <h2 className="text-2xl font-bold text-[rgb(74,6,139)] mb-6">My Approach to Fitness</h2>
        <div className="prose max-w-none text-gray-600 mb-6">
          <p>
            My fitness philosophy is centered around finding joy in movement and creating sustainable habits. I believe that the best workout is the one you'll actually do consistently, which is why I've explored various YouTube workout videos to find what works best for me.
          </p>
          <p>
            Rather than following a rigid 30-day program, I've discovered that mixing different workout styles keeps me engaged and motivated. I regularly follow various YouTube channels that offer everything from yoga and pilates to dance workouts and HIIT sessions.
          </p>
          <p>
            Below I'm sharing my favorite workout channels that have helped me stay consistent with my fitness journey. These diverse resources allow me to choose workouts that match my energy levels and interests each day, making fitness a sustainable part of my lifestyle.
          </p>
        </div>
      </div>

      {/* Workout Categories Navigation */}
      <div className="border-2 border-[#A582D1] rounded-lg p-6 mb-8">
        <h2 className="text-2xl font-bold text-[rgb(74,6,139)] mb-6 text-center">Home Workout Guide</h2>
        <p className="text-gray-600 mb-6 text-center">
          Discover a variety of workouts you can do at home to stay fit and healthy.
          Click on the links below to explore different workout routines tailored to your fitness goals and preferences.
          These workouts are from my personal playlists that I love doing!
        </p>
        <div className="flex justify-center mb-6">
          <WorkoutCategories />
        </div>
      </div>

      {/* Yoga Section */}
      <YogaSection />

      {/* Pilates Section */}
      <WorkoutSection 
        id="pilates"
        title="Best Pilates Channels"
        channels={pilatesChannels}
        description="If you're looking to try pilates at home without spending extra money on studio classes, these channels are your best bet. I've explored MoveWithNicole, MoveWithAgnes, LillySabri, and Blogilates, and they provide challenging workouts that are just as effective as studio classes. Their routines are both slow-paced and intense, making them perfect for achieving a challenging workout from the comfort of your home. Click on the channel names to watch their YouTube videos and start your Pilates journey today!"
      />

      {/* Dance Workout Section */}
      <WorkoutSection 
        id="dance"
        title="Dance Workouts"
        channels={danceChannels}
        description="If you're a person who loves to dance and looking for fun workout alternatives, check out WorkoutWithSabah, DanceWithDeepti, MadFit, and GrowWithJo. I've personally enjoyed using these channels for my workouts. Even if you're not typically interested in working out, trying these dance workouts can be a blast, especially if you do them with friends as group exercise. Give them a try and experience the fun for yourself!"
      />

      {/* HIIT and Cardio Section */}
      <WorkoutSection 
        id="hiit"
        title="HIIT and Cardio"
        channels={hiitChannels}
        description="If you're looking to level up your workouts with weights or start your fitness journey as a beginner, consider checking out Cult.Official, MadFit, GrowingAnnanas, and JuiceandToya. These channels offer a diverse range of workout routines tailored to different fitness levels and preferences. Whether you prefer to incorporate weights into your exercises or start without equipment, you'll find plenty of options here. From intense cardio sessions to strength training workouts, these channels cover all bases, ensuring a comprehensive fitness experience."
      />
    </div>
  );
};

export default Fitness;
