import { useState } from "react";
import PostCard from "@/components/blog/post-card";
import { usePosts, useCategories, getCategoryName } from "@/lib/data";
import { Category } from "@shared/schema";

const Blog = () => {
  const { data: posts, isLoading: postsLoading } = usePosts();
  const { data: categories, isLoading: categoriesLoading } = useCategories();
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  
  // Filter posts by selected category
  const filteredPosts = selectedCategory 
    ? posts?.filter(post => post.categoryId === selectedCategory)
    : posts;
  
  return (
    <div className="max-w-7xl mx-auto px-4 py-8 fade-in">
      <h1 className="text-3xl font-bold text-[rgb(74,6,139)] mb-8 text-center">Blog</h1>
      
      {/* Category Filter */}
      <div className="mb-8">
        <div className="flex flex-wrap justify-center gap-2">
          <button 
            className={`px-4 py-2 rounded-full text-sm ${!selectedCategory ? 'bg-[rgb(74,6,139)] text-white' : 'bg-[#e6e6fa] text-[rgb(63,9,114)] border border-[rgb(62,62,76)]'}`}
            onClick={() => setSelectedCategory(null)}
          >
            All Posts
          </button>
          
          {categoriesLoading ? (
            <div>Loading categories...</div>
          ) : categories?.map(category => (
            <button 
              key={category.id}
              className={`px-4 py-2 rounded-full text-sm ${selectedCategory === category.id ? 'bg-[rgb(74,6,139)] text-white' : 'bg-[#e6e6fa] text-[rgb(63,9,114)] border border-[rgb(62,62,76)]'}`}
              onClick={() => setSelectedCategory(category.id)}
            >
              {category.name}
            </button>
          ))}
        </div>
      </div>
      
      {/* Posts */}
      <div>
        {postsLoading || categoriesLoading ? (
          <div className="text-center py-8">Loading posts...</div>
        ) : filteredPosts && filteredPosts.length > 0 ? (
          filteredPosts.map(post => (
            <PostCard 
              key={post.id}
              post={post}
              categoryName={getCategoryName(categories, post.categoryId)}
            />
          ))
        ) : (
          <div className="text-center py-8 border-2 border-[rgb(62,62,76)] rounded-lg p-8">
            <p className="text-gray-600">No posts found in this category. Try selecting a different category.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Blog;
