import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Loader2 } from "lucide-react";

export default function ProfilePage() {
  const { user, logoutMutation } = useAuth();
  
  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-border" />
      </div>
    );
  }

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <div className="container mx-auto py-10 px-4">
      <h1 className="text-3xl font-bold text-center mb-8 text-[rgb(74,6,139)]">My Account</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-1">
          <Card className="border border-purple-200 shadow-md">
            <CardHeader className="flex flex-col items-center">
              <Avatar className="h-24 w-24 bg-purple-100 border-2 border-purple-300">
                <AvatarFallback className="text-xl font-bold text-purple-600">
                  {user.username.substring(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <CardTitle className="mt-4 text-xl">{user.username}</CardTitle>
              <CardDescription>{user.email}</CardDescription>
            </CardHeader>
            <CardFooter>
              <Button 
                variant="destructive" 
                className="w-full" 
                onClick={handleLogout}
                disabled={logoutMutation.isPending}
              >
                {logoutMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Logging out...
                  </>
                ) : (
                  "Log Out"
                )}
              </Button>
            </CardFooter>
          </Card>
        </div>
        
        <div className="md:col-span-2">
          <Card className="border border-purple-200 shadow-md h-full">
            <CardHeader>
              <CardTitle>Account Settings</CardTitle>
              <CardDescription>Manage your account preferences and settings.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <h3 className="font-medium">Username</h3>
                <p className="text-gray-500">{user.username}</p>
              </div>
              <div className="space-y-2">
                <h3 className="font-medium">Email</h3>
                <p className="text-gray-500">{user.email}</p>
              </div>
              <div className="space-y-2">
                <h3 className="font-medium">Account Type</h3>
                <p className="text-gray-500">{user.isAdmin ? "Administrator" : "Standard User"}</p>
              </div>
            </CardContent>
            <CardFooter>
              <div className="text-sm text-gray-500">
                Account created and managed by Pages of My Journey
              </div>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}