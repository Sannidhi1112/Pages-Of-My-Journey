import Prologue from "@/components/home/prologue";
import CategoryCard from "@/components/home/category-card";
import ContactForm from "@/components/common/contact-form";
import NewsletterForm from "@/components/common/newsletter-form";
import { Link } from "wouter";

const Home = () => {
  
  return (
    <div className="max-w-7xl mx-auto px-4 py-8 fade-in">
      {/* Prologue Section */}
      <Prologue />
      
      {/* Chapters Section */}
      <div className="mb-16">
        <h2 className="text-[rgb(74,6,139)] text-2xl font-bold mb-8 text-center">Chapters of My Journey</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <CategoryCard 
            title="Chapter I: The Fitness Path"
            description="Follow my fitness transformation story, complete with workout guides and wellness discoveries."
            imageUrl="https://images.unsplash.com/photo-1517836357463-d25dfeac3438?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
            linkUrl="/fitness"
            linkText="Read Chapter"
          />
          
          <CategoryCard 
            title="Chapter II: Audio Wisdom"
            description="A collection of podcasts that have shaped my thinking and inspired personal growth."
            imageUrl="https://images.unsplash.com/photo-1589903308904-1010c2294adc?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
            linkUrl="/podcasts"
            linkText="Listen to Stories"
          />
          
          <CategoryCard 
            title="Chapter III: Connect"
            description="The journey continues through conversation. Share your thoughts and connect with me."
            imageUrl="https://images.unsplash.com/photo-1516387938699-a93567ec168e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
            linkUrl="/contact"
            linkText="Begin Dialogue"
          />
        </div>
      </div>
      
      {/* Newsletter & Contact Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
        <NewsletterForm />
        <ContactForm />
      </div>
    </div>
  );
};

export default Home;
