import { Book } from "lucide-react";
import PodcastSection from "@/components/podcasts/podcast-section";
import "@/styles/podcasts.css";

const Podcasts = () => {
  // Casual conversation podcasts
  const casualConversationPodcasts = [
    { name: "Untriggered Podcast", url: "https://www.youtube.com/@UntriggeredPodcast" },
    { name: "THIS IS NOT A PODCAST", url: "https://www.youtube.com/@THISISNOTAPODCAST-rx8ni" },
    { name: "MoS-Pod", url: "https://www.youtube.com/@MoS-Pod/videos" },
    { name: "Permit Room", url: "https://www.youtube.com/@PermitRoom/videos" },
    { name: "The Having Said That Show", url: "https://www.youtube.com/@thehavingsaidthatshow" }
  ];

  // Motivation and learning podcasts
  const motivationalPodcasts = [
    { name: "BeerBiceps", url: "https://www.youtube.com/@beerbiceps" },
    { name: "Nikhil Kamath", url: "https://www.youtube.com/@nikhil.kamath" },
    { name: "Adete Dahiya", url: "https://www.youtube.com/@AdeteDahiya" },
    { name: "The Ranveer Show", url: "https://open.spotify.com/show/408g2DX1LdVYGFpIpBM7Ee" },
    { name: "Humans of Bombay", url: "https://www.youtube.com/@humansofbombay2801" }
  ];

  // Health and fitness podcasts
  const healthPodcasts = [
    { name: "LivEzy", url: "https://www.youtube.com/@LivEzy/featured" },
    { name: "Linda Sun", url: "https://www.youtube.com/@lindasunyt" },
    { name: "Kris Hui", url: "https://www.youtube.com/@KrisHui" },
    { name: "Healthy Emmie", url: "https://www.youtube.com/@HealthyEmmie/featured" },
    { name: "Lidia V. Mera", url: "https://www.youtube.com/@lidiavmera/featured" }
  ];
  
  return (
    <div className="max-w-7xl mx-auto px-4 py-8 fade-in">
      {/* Header with Chapter styling */}
      <div className="text-center mb-12">
        <div className="flex items-center justify-center mb-2">
          <Book className="text-[rgb(74,6,139)] h-8 w-8 mr-2" />
          <h2 className="text-lg font-semibold text-[rgb(74,6,139)]">Chapter 2</h2>
        </div>
        <h1 className="text-3xl font-bold text-[rgb(74,6,139)] mb-4">Motivation on the Go: Podcasts for Every Moment</h1>
        <p className="text-gray-600 max-w-3xl mx-auto">
          As someone who loves to listen to podcasts, I always feel motivated and entertained, whether
          I'm walking, cleaning, or working on other tasks. These podcasts aren't just about motivation—they're
          your perfect companion for every moment of your day.
        </p>
      </div>
      
      {/* Hero Image */}
      <div className="rounded-lg overflow-hidden mb-12 shadow-[8px_8px_2px_0_rgb(87,77,131)] border-2 border-[rgb(62,62,76)]">
        <img 
          src="https://images.unsplash.com/photo-1589903308904-1010c2294adc?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80" 
          alt="Podcast Recommendations"
          className="w-full h-96 object-cover"
        />
      </div>
      
      {/* Introduction Content */}
      <div className="mb-12">
        <div className="prose max-w-none text-gray-600">
          <p className="mb-4">
            Whether you're traveling, working out, or tackling tasks, you can tune in to inspiring conversations and engaging stories that make it easy to stay
            positive and motivated. Plus, you'll have fun along the way! Perfect for anyone looking to enhance
            productivity while staying uplifted.
          </p>
          <p>
            These podcasts have been a constant source of inspiration and entertainment in my daily life.
            I've organized them into categories based on their content and style, so you can find the perfect
            podcast for any mood or situation.
          </p>
        </div>
      </div>
      
      {/* Casual Conversations Section with Accordion */}
      <PodcastSection 
        id="casual-conversations"
        title="Casual Chats and Insightful Conversations with Celebrities"
        channels={casualConversationPodcasts}
        description="These are some of my absolute favorite podcasts to listen to when I want to unwind, laugh, and stay entertained. These podcasts feature a group of friends chatting about trending topics, current events, and everything in between. You'll feel like you're part of their conversation as they invite different guests, including celebrities and influencers, to join in. It's a great way to get to know these guests while having fun listening to their stories and perspectives. Each of these podcasts brings humor, relatability, and interesting discussions, making them my go-to choices for a good time."
      />
      
      {/* Motivation and Learning Section */}
      <PodcastSection 
        id="motivation-learning"
        title="Motivation and Insightful Learning"
        channels={motivationalPodcasts}
        description="When I need a dose of motivation or want to expand my knowledge, these are the podcasts I turn to. These shows feature interviews with successful entrepreneurs, thought leaders, and experts across various fields. They dive deep into topics like personal development, entrepreneurship, philosophy, and innovative thinking. The hosts have a knack for asking thought-provoking questions that extract valuable insights from their guests. You'll walk away from each episode with new perspectives and actionable advice that you can apply to your own life and goals."
      />
      
      {/* Health and Fitness Section */}
      <PodcastSection 
        id="health-fitness"
        title="Fitness, Health, and Balanced Living"
        channels={healthPodcasts}
        description="These podcasts focus on holistic approaches to health, fitness, and nutrition. Whether you're looking for workout motivation, nutrition advice, or strategies for maintaining a balanced lifestyle, these shows have you covered. The hosts share practical tips, bust common myths, and often bring in health experts to discuss the latest research and trends. What I appreciate most about these podcasts is their emphasis on sustainable practices rather than quick fixes, encouraging listeners to develop healthy habits that last a lifetime."
      />
    </div>
  );
};

export default Podcasts;
