import { useQuery } from "@tanstack/react-query";
import { Post, Category, Comment } from "@shared/schema";

// Hook to fetch all categories
export const useCategories = () => {
  return useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });
};

// Hook to fetch a single category by slug
export const useCategory = (slug: string) => {
  return useQuery<Category>({
    queryKey: [`/api/categories/${slug}`],
    enabled: !!slug,
  });
};

// Hook to fetch all posts
export const usePosts = () => {
  return useQuery<Post[]>({
    queryKey: ['/api/posts'],
  });
};

// Hook to fetch posts by category ID
export const usePostsByCategory = (categoryId: number | undefined) => {
  return useQuery<Post[]>({
    queryKey: ['/api/posts', { categoryId }],
    enabled: categoryId !== undefined,
  });
};

// Hook to fetch a single post by slug
export const usePost = (slug: string) => {
  return useQuery<Post>({
    queryKey: [`/api/posts/${slug}`],
    enabled: !!slug,
  });
};

// Hook to fetch comments for a post
export const useComments = (postId: number | undefined) => {
  return useQuery<Comment[]>({
    queryKey: [`/api/posts/${postId}/comments`],
    enabled: postId !== undefined,
  });
};

// Helper function to get a category name by ID
export const getCategoryName = (categories: Category[] | undefined, categoryId: number | null | undefined) => {
  if (!categories || categoryId === undefined || categoryId === null) return "Uncategorized";
  const category = categories.find(cat => cat.id === categoryId);
  return category ? category.name : "Uncategorized";
};
