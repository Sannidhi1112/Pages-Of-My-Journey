import { Switch, Route, useLocation } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";

// Pages
import Home from "@/pages/home";
import Fitness from "@/pages/fitness";
import Podcasts from "@/pages/podcasts";
import Contact from "@/pages/contact";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";

// Admin Pages
import AdminDashboard from "@/pages/admin/index";
import NewsletterSubscribers from "@/pages/admin/newsletters";
import ContactSubmissions from "@/pages/admin/contacts";

// Layout components
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";

// Create Routes Component to organize the app structure
function AppRoutes() {
  return (
    <Switch>
      {/* Public Routes */}
      <Route path="/" component={Home} />
      <Route path="/fitness" component={Fitness} />
      <Route path="/podcasts" component={Podcasts} />
      <Route path="/contact" component={Contact} />
      <Route path="/auth" component={AuthPage} />
      
      {/* Admin Routes - Protected */}
      <Route path="/admin">
        {() => <ProtectedRoute component={AdminDashboard} adminOnly={true} />}
      </Route>
      <Route path="/admin/newsletters">
        {() => <ProtectedRoute component={NewsletterSubscribers} adminOnly={true} />}
      </Route>
      <Route path="/admin/contacts">
        {() => <ProtectedRoute component={ContactSubmissions} adminOnly={true} />}
      </Route>
      
      {/* 404 Route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// Layout manager to control when to show navbar and footer
function LayoutManager() {
  const [location] = useLocation();
  const isAdminPage = location.startsWith('/admin');
  
  if (isAdminPage) {
    return <AppRoutes />;
  }
  
  return (
    <>
      <Navbar />
      <main className="flex-grow">
        <AppRoutes />
      </main>
      <Footer />
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <div className="min-h-screen flex flex-col">
          {/* Using custom layout logic instead of Route */}
          <LayoutManager />
        </div>
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
