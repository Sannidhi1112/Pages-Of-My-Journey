import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Add custom styles to achieve the lavender color scheme
const styleElement = document.createElement("style");
styleElement.textContent = `
  @keyframes slideIn {
    from {
      opacity: 0;
      transform: translateX(-50px);
    }
    to {
      opacity: 1;
      transform: translateX(0px);
    }
  }
  
  @keyframes fadeIn {
    from {
      opacity: 0;
      transform: translateY(10px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
  
  :root {
    --lavender: #e6e6fa;
    --lavender-dark: #c5c5e2;
    --primary: rgb(74, 6, 139);
    --secondary: rgb(63, 9, 114);
    --accent: rgb(119, 119, 213);
    --border: rgb(62, 62, 76);
    --box-shadow: 8px 8px 2px 0 rgb(87, 77, 131);
  }
  
  body {
    background-color: var(--lavender);
    font-family: "Playwrite IN", serif;
    font-optical-sizing: auto;
  }
  
  .slide-in {
    animation: slideIn 2s ease-in-out forwards;
  }
  
  .fade-in {
    animation: fadeIn 0.5s ease-in-out forwards;
  }
`;
document.head.appendChild(styleElement);

createRoot(document.getElementById("root")!).render(<App />);
