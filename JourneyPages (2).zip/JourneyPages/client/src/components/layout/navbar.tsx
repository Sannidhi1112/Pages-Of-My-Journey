import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X } from "lucide-react";

const Navbar = () => {
  const [mobileMenuVisible, setMobileMenuVisible] = useState(false);
  const [location] = useLocation();

  const toggleMobileMenu = () => {
    setMobileMenuVisible(!mobileMenuVisible);
  };

  return (
    <header className="shadow-md bg-lavender">
      <div className="flex justify-between items-center px-4 py-4 max-w-7xl mx-auto">
        <div className="flex items-center">
          <Link href="/">
            <h1 className="text-[rgb(74,6,139)] text-2xl md:text-3xl font-bold slide-in cursor-pointer">
              Pages of My Journey
            </h1>
          </Link>
        </div>
        
        {/* Desktop Navigation */}
        <nav className="hidden md:block">
          <ul className="flex space-x-6">
            <li>
              <Link href="/">
                <span className={`${location === '/' ? 'text-[rgb(74,6,139)]' : 'text-gray-600'} hover:text-[rgb(74,6,139)] transition duration-300 cursor-pointer`}>
                  Home
                </span>
              </Link>
            </li>

            <li>
              <Link href="/fitness">
                <span className={`${location === '/fitness' ? 'text-[rgb(74,6,139)]' : 'text-gray-600'} hover:text-[rgb(74,6,139)] transition duration-300 cursor-pointer`}>
                  Fitness
                </span>
              </Link>
            </li>
            <li>
              <Link href="/podcasts">
                <span className={`${location === '/podcasts' ? 'text-[rgb(74,6,139)]' : 'text-gray-600'} hover:text-[rgb(74,6,139)] transition duration-300 cursor-pointer`}>
                  Podcasts
                </span>
              </Link>
            </li>
            <li>
              <Link href="/contact">
                <span className={`${location === '/contact' ? 'text-[rgb(74,6,139)]' : 'text-gray-600'} hover:text-[rgb(74,6,139)] transition duration-300 cursor-pointer`}>
                  Contact
                </span>
              </Link>
            </li>
          </ul>
        </nav>
        
        {/* Mobile Menu Button */}
        <button 
          className="md:hidden text-[rgb(74,6,139)] focus:outline-none"
          onClick={toggleMobileMenu}
        >
          {mobileMenuVisible ? (
            <X className="h-6 w-6" />
          ) : (
            <Menu className="h-6 w-6" />
          )}
        </button>
      </div>
      
      {/* Mobile Menu */}
      {mobileMenuVisible && (
        <div className="md:hidden">
          <ul className="px-4 py-2 space-y-2 shadow-md">
            <li>
              <Link href="/">
                <span 
                  className={`block py-2 ${location === '/' ? 'text-[rgb(74,6,139)]' : 'text-gray-600'} hover:text-[rgb(74,6,139)] cursor-pointer`}
                  onClick={() => setMobileMenuVisible(false)}
                >
                  Home
                </span>
              </Link>
            </li>

            <li>
              <Link href="/fitness">
                <span 
                  className={`block py-2 ${location === '/fitness' ? 'text-[rgb(74,6,139)]' : 'text-gray-600'} hover:text-[rgb(74,6,139)] cursor-pointer`}
                  onClick={() => setMobileMenuVisible(false)}
                >
                  Fitness
                </span>
              </Link>
            </li>
            <li>
              <Link href="/podcasts">
                <span 
                  className={`block py-2 ${location === '/podcasts' ? 'text-[rgb(74,6,139)]' : 'text-gray-600'} hover:text-[rgb(74,6,139)] cursor-pointer`}
                  onClick={() => setMobileMenuVisible(false)}
                >
                  Podcasts
                </span>
              </Link>
            </li>
            <li>
              <Link href="/contact">
                <span 
                  className={`block py-2 ${location === '/contact' ? 'text-[rgb(74,6,139)]' : 'text-gray-600'} hover:text-[rgb(74,6,139)] cursor-pointer`}
                  onClick={() => setMobileMenuVisible(false)}
                >
                  Contact
                </span>
              </Link>
            </li>
          </ul>
        </div>
      )}
    </header>
  );
};

export default Navbar;
