import { Link } from "wouter";
import { Twitter, Instagram, Facebook } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-lavender border-t border-[rgb(62,62,76)] mt-auto">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <h3 className="text-[rgb(74,6,139)] font-bold text-lg mb-4">Pages of My Journey</h3>
            <p className="text-gray-600 mb-4">
              Sharing my personal path toward better health, fitness, and self-growth. 
              Join me on this journey of discovery and transformation.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-[rgb(63,9,114)] hover:text-[rgb(74,6,139)] transition duration-300" aria-label="Twitter">
                <Twitter className="h-6 w-6" />
              </a>
              <a href="#" className="text-[rgb(63,9,114)] hover:text-[rgb(74,6,139)] transition duration-300" aria-label="Instagram">
                <Instagram className="h-6 w-6" />
              </a>
              <a href="#" className="text-[rgb(63,9,114)] hover:text-[rgb(74,6,139)] transition duration-300" aria-label="Facebook">
                <Facebook className="h-6 w-6" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-[rgb(74,6,139)] font-bold text-lg mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/">
                  <span className="text-gray-600 hover:text-[rgb(74,6,139)] transition duration-300 cursor-pointer">Home</span>
                </Link>
              </li>

              <li>
                <Link href="/fitness">
                  <span className="text-gray-600 hover:text-[rgb(74,6,139)] transition duration-300 cursor-pointer">Fitness</span>
                </Link>
              </li>
              <li>
                <Link href="/podcasts">
                  <span className="text-gray-600 hover:text-[rgb(74,6,139)] transition duration-300 cursor-pointer">Podcasts</span>
                </Link>
              </li>
              <li>
                <Link href="/contact">
                  <span className="text-gray-600 hover:text-[rgb(74,6,139)] transition duration-300 cursor-pointer">Contact</span>
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-[rgb(74,6,139)] font-bold text-lg mb-4">Categories</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/fitness">
                  <span className="text-gray-600 hover:text-[rgb(74,6,139)] transition duration-300 cursor-pointer">Fitness</span>
                </Link>
              </li>
              <li>
                <a href="#" className="text-gray-600 hover:text-[rgb(74,6,139)] transition duration-300">Nutrition</a>
              </li>
              <li>
                <a href="#" className="text-gray-600 hover:text-[rgb(74,6,139)] transition duration-300">Mindfulness</a>
              </li>
              <li>
                <Link href="/podcasts">
                  <span className="text-gray-600 hover:text-[rgb(74,6,139)] transition duration-300 cursor-pointer">Podcast Reviews</span>
                </Link>
              </li>
              <li>
                <a href="#" className="text-gray-600 hover:text-[rgb(74,6,139)] transition duration-300">Personal Growth</a>
              </li>
              <li>
                <a href="#" className="text-gray-600 hover:text-[rgb(74,6,139)] transition duration-300">Workout Routines</a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-[rgb(62,62,76)] mt-8 pt-6 text-center">
          <p className="text-gray-600">Copyright © {new Date().getFullYear()} - Pages of My Journey</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
