import React from 'react';
import { ExternalLink } from 'lucide-react';
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

interface PodcastChannelProps {
  name: string;
  url: string;
}

interface PodcastSectionProps {
  id: string;
  title: string;
  description: string;
  channels: Array<{name: string, url: string}>;
}

const PodcastChannel = ({ name, url }: PodcastChannelProps) => {
  return (
    <div className="podcast-channel p-3 rounded-md hover:bg-[rgba(165,130,209,0.1)] transition-colors duration-200">
      <a 
        href={url} 
        target="_blank" 
        rel="noopener noreferrer" 
        className="flex items-center"
      >
        <div className="flex-1">
          <span className="channel-name block font-medium">{name}</span>
        </div>
        <div className="ml-2">
          <ExternalLink size={18} className="text-[rgb(74,6,139)]" />
        </div>
      </a>
    </div>
  );
};

const PodcastSection = ({ id, title, description, channels }: PodcastSectionProps) => {
  return (
    <div id={id} className="border-2 border-[rgb(62,62,76)] shadow-[8px_8px_2px_0_rgb(87,77,131)] rounded-lg p-6 mb-12">
      <h2 className="text-2xl font-bold text-[rgb(74,6,139)] mb-6 text-center">{title}</h2>
      
      <Accordion type="single" collapsible className="w-full">
        <AccordionItem value="description" className="border-b-2 border-[rgba(165,130,209,0.3)]">
          <AccordionTrigger className="text-lg font-semibold text-[rgb(74,6,139)]">
            About This Collection
          </AccordionTrigger>
          <AccordionContent>
            <p className="text-gray-600 py-2">{description}</p>
          </AccordionContent>
        </AccordionItem>
        
        <AccordionItem value="channels" className="border-b-0">
          <AccordionTrigger className="text-lg font-semibold text-[rgb(74,6,139)]">
            Recommended Channels
          </AccordionTrigger>
          <AccordionContent>
            <div className="grid grid-cols-1 divide-y divide-[rgba(165,130,209,0.2)]">
              {channels.map((channel, index) => (
                <PodcastChannel 
                  key={index}
                  name={channel.name}
                  url={channel.url}
                />
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  );
};

export default PodcastSection;