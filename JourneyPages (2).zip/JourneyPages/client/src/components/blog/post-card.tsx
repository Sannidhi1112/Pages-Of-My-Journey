import { Link } from "wouter";
import { Post } from "@shared/schema";
import { formatDistance } from "date-fns";

interface PostCardProps {
  post: Post;
  categoryName: string;
}

const PostCard = ({ post, categoryName }: PostCardProps) => {
  const formattedDate = formatDistance(
    new Date(post.createdAt),
    new Date(),
    { addSuffix: true }
  );

  return (
    <div className="border-2 border-[rgb(62,62,76)] shadow-md rounded-lg p-6 mb-6 hover:shadow-[8px_8px_2px_0_rgb(87,77,131)] transition duration-300">
      <div className="flex flex-col md:flex-row">
        <div className="md:w-1/4 mb-4 md:mb-0 md:mr-6">
          <img 
            src={post.coverImage} 
            alt={`Cover image for ${post.title}`} 
            className="w-full h-40 object-cover rounded-lg"
          />
        </div>
        <div className="md:w-3/4">
          <span className="inline-block bg-[#c5c5e2] px-3 py-1 rounded-full text-sm text-[rgb(63,9,114)] mb-2">
            {categoryName}
          </span>
          <h3 className="text-xl font-bold text-[rgb(74,6,139)] mb-2">{post.title}</h3>
          <p className="text-gray-600 mb-4">{post.excerpt}</p>
          <div className="flex justify-between items-center">
            <span className="text-gray-500 text-sm">{formattedDate}</span>
            <Link href={`/blog/${post.slug}`}>
              <a className="text-[rgb(63,9,114)] hover:text-[rgb(119,119,213)] transition duration-300">
                Read Post →
              </a>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PostCard;
