import { formatDistance } from "date-fns";
import { Comment as CommentType } from "@shared/schema";

interface CommentProps {
  comment: CommentType;
}

const Comment = ({ comment }: CommentProps) => {
  const formattedDate = formatDistance(
    new Date(comment.createdAt),
    new Date(),
    { addSuffix: true }
  );

  // Get initials for avatar
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase();
  };

  const initials = getInitials(comment.name);

  return (
    <div className="border-2 border-[rgb(62,62,76)] rounded-lg p-4 mb-4">
      <div className="flex items-start space-x-4">
        <div className="w-10 h-10 rounded-full bg-[#c5c5e2] flex items-center justify-center text-[rgb(74,6,139)] font-bold">
          {initials}
        </div>
        <div className="flex-1">
          <div className="flex justify-between items-center mb-2">
            <h4 className="font-medium text-[rgb(74,6,139)]">{comment.name}</h4>
            <span className="text-gray-500 text-sm">{formattedDate}</span>
          </div>
          <p className="text-gray-600">{comment.content}</p>
        </div>
      </div>
    </div>
  );
};

export default Comment;
