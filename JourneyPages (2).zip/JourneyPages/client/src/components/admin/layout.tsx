import { ReactNode } from "react";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link, useLocation } from "wouter";

interface AdminLayoutProps {
  children: ReactNode;
}

export default function AdminLayout({ children }: AdminLayoutProps) {
  const [location] = useLocation();
  
  const getTabValue = () => {
    if (location === "/admin") return "overview";
    if (location === "/admin/newsletters") return "newsletters";
    if (location === "/admin/contacts") return "contacts";
    return "overview";
  };

  return (
    <div className="flex min-h-screen flex-col">
      <div className="border-b">
        <div className="flex h-16 items-center px-4">
          <div className="flex items-center">
            <Link href="/admin">
              <span className="font-bold text-xl cursor-pointer">Admin Dashboard</span>
            </Link>
          </div>
          <div className="ml-auto flex items-center space-x-4">
            {/* Add admin profile, notifications, etc. if needed */}
          </div>
        </div>
      </div>
      <div className="flex-1 space-y-4 p-8 pt-6">
        <Tabs defaultValue={getTabValue()} className="space-y-4">
          <TabsList>
            <Link href="/admin">
              <TabsTrigger value="overview">Overview</TabsTrigger>
            </Link>
            <Link href="/admin/newsletters">
              <TabsTrigger value="newsletters">Newsletter Subscribers</TabsTrigger>
            </Link>
            <Link href="/admin/contacts">
              <TabsTrigger value="contacts">Contact Submissions</TabsTrigger>
            </Link>
          </TabsList>
          {children}
        </Tabs>
      </div>
    </div>
  );
}