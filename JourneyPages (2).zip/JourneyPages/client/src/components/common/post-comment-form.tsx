import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertCommentSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Extend the comment schema with validation
const commentFormSchema = insertCommentSchema
  .omit({ postId: true })
  .extend({
    name: z.string().min(2, "Name must be at least 2 characters"),
    email: z.string().email("Please enter a valid email address"),
    content: z.string().min(5, "Comment must be at least 5 characters"),
  });

type CommentFormValues = z.infer<typeof commentFormSchema>;

interface PostCommentFormProps {
  postId: number;
}

const PostCommentForm = ({ postId }: PostCommentFormProps) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { register, handleSubmit, reset, formState: { errors } } = useForm<CommentFormValues>({
    resolver: zodResolver(commentFormSchema),
    defaultValues: {
      name: "",
      email: "",
      content: "",
    },
  });
  
  const commentMutation = useMutation({
    mutationFn: async (data: CommentFormValues) => {
      return apiRequest("POST", "/api/comments", {
        ...data,
        postId,
      });
    },
    onSuccess: () => {
      toast({
        title: "Comment Posted",
        description: "Your comment has been successfully posted.",
      });
      reset();
      // Invalidate cache to refetch comments
      queryClient.invalidateQueries({ queryKey: [`/api/posts/${postId}/comments`] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to post comment. Please try again later.",
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (data: CommentFormValues) => {
    commentMutation.mutate(data);
  };
  
  return (
    <div className="mt-8">
      <h4 className="font-semibold text-[rgb(74,6,139)] mb-4">Leave a Comment</h4>
      
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div>
          <label htmlFor="commentName" className="block text-[rgb(63,9,114)] font-medium mb-1">Name</label>
          <input 
            type="text" 
            id="commentName" 
            {...register("name")}
            className="w-full px-3 py-2 border border-[rgb(62,62,76)] rounded-md focus:outline-none focus:ring-2 focus:ring-[rgb(74,6,139)]"
          />
          {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name.message}</p>}
        </div>
        
        <div>
          <label htmlFor="commentEmail" className="block text-[rgb(63,9,114)] font-medium mb-1">Email</label>
          <input 
            type="email" 
            id="commentEmail" 
            {...register("email")}
            className="w-full px-3 py-2 border border-[rgb(62,62,76)] rounded-md focus:outline-none focus:ring-2 focus:ring-[rgb(74,6,139)]"
          />
          {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email.message}</p>}
        </div>
        
        <div>
          <label htmlFor="commentContent" className="block text-[rgb(63,9,114)] font-medium mb-1">Comment</label>
          <textarea 
            id="commentContent" 
            {...register("content")}
            rows={4} 
            className="w-full px-3 py-2 border border-[rgb(62,62,76)] rounded-md focus:outline-none focus:ring-2 focus:ring-[rgb(74,6,139)]"
          ></textarea>
          {errors.content && <p className="text-red-500 text-sm mt-1">{errors.content.message}</p>}
        </div>
        
        <button 
          type="submit" 
          className="bg-[rgb(74,6,139)] hover:bg-[rgb(63,9,114)] text-white font-medium py-2 px-6 rounded-md transition duration-300"
          disabled={commentMutation.isPending}
        >
          {commentMutation.isPending ? "Posting..." : "Post Comment"}
        </button>
      </form>
    </div>
  );
};

export default PostCommentForm;
