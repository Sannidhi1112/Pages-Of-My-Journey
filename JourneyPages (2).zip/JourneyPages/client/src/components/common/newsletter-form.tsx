import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertNewsletterSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Extend the newsletter schema with validation
const newsletterFormSchema = insertNewsletterSchema.extend({
  email: z.string().email("Please enter a valid email address"),
  consent: z.boolean().refine(val => val === true, {
    message: "You must agree to receive emails",
  }),
});

type NewsletterFormValues = z.infer<typeof newsletterFormSchema> & { consent: boolean };

const NewsletterForm = () => {
  const { toast } = useToast();
  
  const { register, handleSubmit, reset, formState: { errors } } = useForm<NewsletterFormValues>({
    resolver: zodResolver(newsletterFormSchema),
    defaultValues: {
      email: "",
      consent: false,
    },
  });
  
  const newsletterMutation = useMutation({
    mutationFn: async (data: { email: string }) => {
      return apiRequest("POST", "/api/newsletter", data);
    },
    onSuccess: () => {
      toast({
        title: "Subscription Successful",
        description: "Thank you for subscribing to our newsletter!",
      });
      reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to subscribe. Please try again later.",
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (data: NewsletterFormValues) => {
    newsletterMutation.mutate({ email: data.email });
  };
  
  return (
    <div className="border-2 border-[rgb(62,62,76)] p-6 shadow-[8px_8px_2px_0_rgb(87,77,131)] rounded-lg">
      <h2 className="text-[rgb(74,6,139)] text-xl font-bold mb-4">Subscribe to My Newsletter</h2>
      <p className="text-gray-600 mb-4">Get the latest updates, tips, and insights delivered straight to your inbox!</p>
      
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div>
          <label htmlFor="newsletterEmail" className="block text-[rgb(63,9,114)] font-medium mb-1">Email Address</label>
          <input 
            type="email" 
            id="newsletterEmail" 
            {...register("email")}
            className="w-full px-3 py-2 border border-[rgb(62,62,76)] rounded-md focus:outline-none focus:ring-2 focus:ring-[rgb(74,6,139)]"
            placeholder="your@email.com"
          />
          {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email.message}</p>}
        </div>
        
        <div>
          <label className="flex items-start space-x-2">
            <input 
              type="checkbox" 
              className="mt-1" 
              {...register("consent")}
            />
            <span className="text-gray-600 text-sm">I agree to receive emails about new posts and updates.</span>
          </label>
          {errors.consent && <p className="text-red-500 text-sm mt-1">{errors.consent.message}</p>}
        </div>
        
        <button 
          type="submit" 
          className="w-full bg-[rgb(74,6,139)] hover:bg-[rgb(63,9,114)] text-white font-medium py-2 px-4 rounded-md transition duration-300"
          disabled={newsletterMutation.isPending}
        >
          {newsletterMutation.isPending ? "Subscribing..." : "Subscribe"}
        </button>
      </form>
    </div>
  );
};

export default NewsletterForm;
