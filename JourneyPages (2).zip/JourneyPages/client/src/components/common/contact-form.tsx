import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertContactSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Extend the contact schema with validation
const contactFormSchema = insertContactSchema.extend({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email address"),
  message: z.string().min(10, "Message must be at least 10 characters"),
});

type ContactFormValues = z.infer<typeof contactFormSchema>;

const ContactForm = () => {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const { register, handleSubmit, reset, formState: { errors } } = useForm<ContactFormValues>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: "",
      email: "",
      message: "",
    },
  });
  
  const contactMutation = useMutation({
    mutationFn: async (data: ContactFormValues) => {
      return apiRequest("POST", "/api/contact", data);
    },
    onSuccess: () => {
      toast({
        title: "Message Sent",
        description: "Thank you for reaching out! I'll get back to you soon.",
      });
      reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again later.",
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (data: ContactFormValues) => {
    contactMutation.mutate(data);
  };
  
  return (
    <div className="border-2 border-[rgb(62,62,76)] p-6 shadow-[8px_8px_2px_0_rgb(87,77,131)] rounded-lg">
      <h2 className="text-[rgb(74,6,139)] text-xl font-bold mb-4">Get in Touch</h2>
      <p className="text-gray-600 mb-4">Have questions or suggestions? I'd love to hear from you!</p>
      
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div>
          <label htmlFor="name" className="block text-[rgb(63,9,114)] font-medium mb-1">Name</label>
          <input 
            type="text" 
            id="name" 
            {...register("name")}
            className="w-full px-3 py-2 border border-[rgb(62,62,76)] rounded-md focus:outline-none focus:ring-2 focus:ring-[rgb(74,6,139)]"
            placeholder="Your Name"
          />
          {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name.message}</p>}
        </div>
        
        <div>
          <label htmlFor="email" className="block text-[rgb(63,9,114)] font-medium mb-1">Email</label>
          <input 
            type="email" 
            id="email" 
            {...register("email")}
            className="w-full px-3 py-2 border border-[rgb(62,62,76)] rounded-md focus:outline-none focus:ring-2 focus:ring-[rgb(74,6,139)]"
            placeholder="your@email.com"
          />
          {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email.message}</p>}
        </div>
        
        <div>
          <label htmlFor="message" className="block text-[rgb(63,9,114)] font-medium mb-1">Message</label>
          <textarea 
            id="message" 
            {...register("message")}
            rows={4} 
            className="w-full px-3 py-2 border border-[rgb(62,62,76)] rounded-md focus:outline-none focus:ring-2 focus:ring-[rgb(74,6,139)]"
            placeholder="Your message here..."
          ></textarea>
          {errors.message && <p className="text-red-500 text-sm mt-1">{errors.message.message}</p>}
        </div>
        
        <button 
          type="submit" 
          className="w-full bg-[rgb(74,6,139)] hover:bg-[rgb(63,9,114)] text-white font-medium py-2 px-4 rounded-md transition duration-300"
          disabled={contactMutation.isPending}
        >
          {contactMutation.isPending ? "Sending..." : "Send Message"}
        </button>
      </form>
    </div>
  );
};

export default ContactForm;
