import React from 'react';
import { ExternalLink } from 'lucide-react';

const YogaSection = () => {
  const yogaChannels = [
    {
      name: "CharlieFollows",
      url: "https://www.youtube.com/@CharlieFollows",
      description: "This channel is perfect for people who love yoga, offering videos that range from beginner to advanced levels. Among all the YouTube channels I've tried, I love her videos the most because they are accessible, well-structured, and cater to a wide range of abilities. The locations she chooses for her videos, combined with her effective yoga practices and calming voice, make her sessions especially impressive and enjoyable."
    },
    {
      name: "yogawithadriene",
      url: "https://www.youtube.com/@yogawithadriene",
      description: "One of the best things about this channel is the annual 30 Day Yoga Journey that Adriene releases every January. These 30-day series are incredibly calming and effective, providing a wonderful way to start the new year with a solid yoga practice. Adrienes approachable and inclusive teaching style makes yoga accessible to everyone, regardless of their experience level."
    },
    {
      name: "YogalatesWithRashmi",
      url: "https://www.youtube.com/@YogalatesWithRashmi",
      description: "Rashmis Surya Namaskar videos are fantastic, giving me a challenging workout for both body and mind. When I want a tough session, I turn to her Surya Namaskar routines or try her other challenging yoga practices. Rashmis guidance pushes me to do my best and feel accomplished after each workout."
    },
    {
      name: "YogaForCureVideos",
      url: "https://www.youtube.com/@YogaForCureVideos",
      description: "This was my go-to channel when I was a beginner in yoga. The detailed explanations in her videos helped me understand how to do each pose correctly. It is great for beginners, as well as those at other levels, because of the clear instructions provided."
    },
    {
      name: "YogBela",
      url: "https://www.youtube.com/@YogBela",
      description: "This was the first channel where I started my yoga journey. Their beginner playlist taught me a lot when I was new to yoga. They offer various playlists, including intense workouts, for those seeking more challenging routines."
    }
  ];

  return (
    <div id="yoga" className="border-2 border-[rgb(62,62,76)] shadow-[8px_8px_2px_0_rgb(87,77,131)] rounded-lg p-6 mb-12">
      <h2 className="text-2xl font-bold text-[rgb(74,6,139)] mb-6 text-center">Best Yoga Channels</h2>
      <p className="text-gray-600 mb-6 text-center">
        Yoga has been a transformative practice in my fitness journey, helping me improve flexibility, 
        reduce stress, and build mindfulness. These are my personal favorite YouTube channels that have 
        helped me develop a consistent yoga practice over the years.
      </p>
      <div className="grid grid-cols-1 gap-6">
        {yogaChannels.map((channel, index) => (
          <div key={index} className="yoga-card p-6 border-2 border-[rgb(62,62,76)] rounded-lg shadow-md bg-white">
            <h3 className="text-xl font-bold text-[rgb(74,6,139)] mb-3">{channel.name}</h3>
            <p className="text-gray-700 mb-4">
              {channel.description}
            </p>
            <div className="text-center">
              <a 
                href={channel.url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-[rgb(74,6,139)] hover:bg-[rgb(63,9,114)] text-white font-medium py-2 px-6 rounded-full transition duration-300"
              >
                Visit Channel <ExternalLink size={16} />
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default YogaSection;