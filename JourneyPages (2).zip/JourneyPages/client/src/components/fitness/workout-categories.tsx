import React from 'react';
import { FlameIcon, Dumbbell, Music, ShoppingBag } from 'lucide-react';

interface WorkoutCategoryItemProps {
  title: string;
  id: string;
  icon: React.ReactNode;
  description: string;
}

const WorkoutCategoryItem = ({ title, id, icon, description }: WorkoutCategoryItemProps) => {
  return (
    <a href={`#${id}`} className="workout-category block mx-2 mb-6 p-4 bg-white border-2 border-[rgb(62,62,76)] rounded-lg shadow-[4px_4px_1px_0_rgb(87,77,131)] hover:shadow-[8px_8px_2px_0_rgb(87,77,131)] transition-all duration-300 w-[220px]">
      <div className="flex flex-col items-center text-center">
        <div className="text-[rgb(74,6,139)] text-4xl mb-3">
          {icon}
        </div>
        <h3 className="text-lg font-bold text-[rgb(74,6,139)] mb-2">{title}</h3>
        <p className="text-sm text-gray-600">{description}</p>
      </div>
    </a>
  );
};

const WorkoutCategories = () => {
  const categories = [
    {
      id: 'yoga',
      title: 'Yoga',
      icon: <FlameIcon size={32} />,
      description: 'Improve flexibility, balance, and mental clarity with yoga workouts for all levels.'
    },
    {
      id: 'pilates',
      title: 'Pilates',
      icon: <Dumbbell size={32} />,
      description: 'Strengthen your core and improve posture with low-impact pilates exercises.'
    },
    {
      id: 'dance',
      title: 'Dance',
      icon: <Music size={32} />,
      description: 'Get your heart pumping with fun dance workouts that don\'t feel like exercise.'
    },
    {
      id: 'hiit',
      title: 'HIIT & Cardio',
      icon: <ShoppingBag size={32} />,
      description: 'Maximize calorie burn with high-intensity interval training and cardio workouts.'
    }
  ];

  return (
    <div className="flex flex-wrap justify-center">
      {categories.map((category) => (
        <WorkoutCategoryItem
          key={category.id}
          id={category.id}
          title={category.title}
          icon={category.icon}
          description={category.description}
        />
      ))}
    </div>
  );
};

export default WorkoutCategories;