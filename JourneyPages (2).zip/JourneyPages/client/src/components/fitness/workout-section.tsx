import React from 'react';
import { ExternalLink } from 'lucide-react';

interface WorkoutChannelProps {
  name: string;
  url: string;
}

interface WorkoutSectionProps {
  id: string;
  title: string;
  channels: Array<{name: string, url: string}>;
  description: string;
}

const WorkoutChannel = ({ name, url }: WorkoutChannelProps) => {
  return (
    <a 
      href={url} 
      target="_blank" 
      rel="noopener noreferrer" 
      className="workout-channel flex items-center"
    >
      <div className="flex-1">
        <span className="channel-name block">{name}</span>
      </div>
      <div className="ml-2">
        <ExternalLink size={18} className="text-[rgb(74,6,139)] group-hover:text-white" />
      </div>
    </a>
  );
};

const WorkoutSection = ({ id, title, channels, description }: WorkoutSectionProps) => {
  return (
    <div id={id} className="border-2 border-[rgb(62,62,76)] shadow-[8px_8px_2px_0_rgb(87,77,131)] rounded-lg p-6 mb-12">
      <h2 className="text-2xl font-bold text-[rgb(74,6,139)] mb-6 text-center">{title}</h2>
      <p className="text-gray-600 mb-6 text-center">
        {description}
      </p>
      <div className="workout-channels">
        {channels.map((channel, index) => (
          <WorkoutChannel 
            key={index}
            name={channel.name}
            url={channel.url}
          />
        ))}
      </div>
    </div>
  );
};

export default WorkoutSection;