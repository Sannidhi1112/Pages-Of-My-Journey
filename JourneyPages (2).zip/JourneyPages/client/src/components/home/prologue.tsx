import { Link } from "wouter";

const Prologue = () => {
  return (
    <div className="mx-auto max-w-3xl border-2 border-[rgb(62,62,76)] p-8 shadow-[8px_8px_2px_0_rgb(87,77,131)] rounded-lg mb-12">
      <h2 className="text-[rgb(74,6,139)] text-2xl font-bold mb-4 text-center">Prologue</h2>
      <p className="text-gray-600 mb-6">
        Welcome to <strong>Pages of My Journey</strong>. In this personal memoir, I chronicle my path toward better health and
        fitness, with chapters dedicated to self-love, personal growth, and the adventures of continuous learning.
        Each page reveals discoveries, resources, and insights that transformed my story—from workout routines to enlightening podcasts.
      </p>
      <div className="text-center">
        <Link href="/">
          <span className="text-[rgb(63,9,114)] hover:text-[rgb(74,6,139)] transition duration-300 font-medium cursor-pointer">
            Begin the Journey
          </span>
        </Link>
      </div>
    </div>
  );
};

export default Prologue;
