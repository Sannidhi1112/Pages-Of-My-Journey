import { Link } from "wouter";
import { BookOpen } from "lucide-react";

interface CategoryCardProps {
  title: string;
  description: string;
  imageUrl: string;
  linkUrl: string;
  linkText: string;
}

const CategoryCard = ({ title, description, imageUrl, linkUrl, linkText }: CategoryCardProps) => {
  return (
    <div className="border-2 border-[rgb(62,62,76)] shadow-[8px_8px_2px_0_rgb(87,77,131)] rounded-lg overflow-hidden hover:scale-105 transition-transform duration-400 ease-[cubic-bezier(0.075,0.82,0.165,1)] bg-white">
      <div className="relative">
        <div className="absolute top-2 left-2 bg-[rgb(74,6,139)] text-white p-2 rounded-full z-10">
          <BookOpen size={24} />
        </div>
        <div className="h-64 w-full overflow-hidden">
          <img 
            src={imageUrl} 
            alt={`${title} image`} 
            className="w-full h-full object-cover"
          />
        </div>
      </div>
      <div className="p-6 border-t-2 border-[rgb(62,62,76)]">
        <h3 className="text-xl font-semibold text-[rgb(74,6,139)] mb-3">{title}</h3>
        <p className="text-gray-600 mb-5 italic">{description}</p>
        <Link href={linkUrl}>
          <a className="inline-flex items-center text-[rgb(63,9,114)] hover:text-[rgb(119,119,213)] transition duration-300 font-medium">
            {linkText} <span className="ml-1">→</span>
          </a>
        </Link>
      </div>
    </div>
  );
};

export default CategoryCard;
