import {
  users, type User, type InsertUser,
  categories, type Category, type InsertCategory,
  posts, type Post, type InsertPost,
  comments, type Comment, type InsertComment,
  newsletters, type Newsletter, type InsertNewsletter,
  contacts, type Contact, type InsertContact
} from "@shared/schema";

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Category operations
  getCategories(): Promise<Category[]>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  
  // Post operations
  getPosts(): Promise<Post[]>;
  getPostsByCategory(categoryId: number): Promise<Post[]>;
  getPostBySlug(slug: string): Promise<Post | undefined>;
  createPost(post: InsertPost): Promise<Post>;
  
  // Comment operations
  getCommentsByPost(postId: number): Promise<Comment[]>;
  createComment(comment: InsertComment): Promise<Comment>;
  
  // Newsletter operations
  createNewsletterSubscription(newsletter: InsertNewsletter): Promise<Newsletter>;
  getNewsletterSubscriptions(): Promise<Newsletter[]>;
  
  // Contact operations
  createContactSubmission(contact: InsertContact): Promise<Contact>;
  getContactSubmissions(): Promise<Contact[]>;
}

// Memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private categories: Map<number, Category>;
  private posts: Map<number, Post>;
  private comments: Map<number, Comment>;
  private newsletters: Map<number, Newsletter>;
  private contacts: Map<number, Contact>;
  
  private userIdCounter: number;
  private categoryIdCounter: number;
  private postIdCounter: number;
  private commentIdCounter: number;
  private newsletterIdCounter: number;
  private contactIdCounter: number;
  
  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.posts = new Map();
    this.comments = new Map();
    this.newsletters = new Map();
    this.contacts = new Map();
    
    this.userIdCounter = 1;
    this.categoryIdCounter = 1;
    this.postIdCounter = 1;
    this.commentIdCounter = 1;
    this.newsletterIdCounter = 1;
    this.contactIdCounter = 1;
    
    // Initialize with sample data
    this.initializeData();
  }
  
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase()
    );
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { 
      ...insertUser, 
      id,
      isAdmin: insertUser.isAdmin ?? false 
    };
    this.users.set(id, user);
    return user;
  }
  
  // Category operations
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }
  
  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    return Array.from(this.categories.values()).find(
      (category) => category.slug === slug
    );
  }
  
  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = this.categoryIdCounter++;
    const category: Category = { 
      ...insertCategory, 
      id,
      description: insertCategory.description ?? null
    };
    this.categories.set(id, category);
    return category;
  }
  
  // Post operations
  async getPosts(): Promise<Post[]> {
    return Array.from(this.posts.values()).sort((a, b) => {
      const dateA = new Date(a.createdAt).getTime();
      const dateB = new Date(b.createdAt).getTime();
      return dateB - dateA; // Sort by newest first
    });
  }
  
  async getPostsByCategory(categoryId: number): Promise<Post[]> {
    return Array.from(this.posts.values())
      .filter(post => post.categoryId === categoryId)
      .sort((a, b) => {
        const dateA = new Date(a.createdAt).getTime();
        const dateB = new Date(b.createdAt).getTime();
        return dateB - dateA; // Sort by newest first
      });
  }
  
  async getPostBySlug(slug: string): Promise<Post | undefined> {
    return Array.from(this.posts.values()).find(
      (post) => post.slug === slug
    );
  }
  
  async createPost(insertPost: InsertPost): Promise<Post> {
    const id = this.postIdCounter++;
    const now = new Date();
    const post: Post = { 
      ...insertPost, 
      id, 
      createdAt: now,
      excerpt: insertPost.excerpt ?? null,
      coverImage: insertPost.coverImage ?? null,
      authorId: insertPost.authorId ?? null,
      categoryId: insertPost.categoryId ?? null
    };
    this.posts.set(id, post);
    return post;
  }
  
  // Comment operations
  async getCommentsByPost(postId: number): Promise<Comment[]> {
    return Array.from(this.comments.values())
      .filter(comment => comment.postId === postId)
      .sort((a, b) => {
        const dateA = new Date(a.createdAt).getTime();
        const dateB = new Date(b.createdAt).getTime();
        return dateB - dateA; // Sort by newest first
      });
  }
  
  async createComment(insertComment: InsertComment): Promise<Comment> {
    const id = this.commentIdCounter++;
    const now = new Date();
    const comment: Comment = { 
      ...insertComment, 
      id, 
      createdAt: now,
      postId: insertComment.postId ?? null 
    };
    this.comments.set(id, comment);
    return comment;
  }
  
  // Newsletter operations
  async createNewsletterSubscription(insertNewsletter: InsertNewsletter): Promise<Newsletter> {
    // Check if email already exists
    const existingSubscription = Array.from(this.newsletters.values()).find(
      (newsletter) => newsletter.email.toLowerCase() === insertNewsletter.email.toLowerCase()
    );
    
    if (existingSubscription) {
      return existingSubscription;
    }
    
    const id = this.newsletterIdCounter++;
    const now = new Date();
    const newsletter: Newsletter = { 
      ...insertNewsletter, 
      id, 
      createdAt: now 
    };
    this.newsletters.set(id, newsletter);
    return newsletter;
  }
  
  async getNewsletterSubscriptions(): Promise<Newsletter[]> {
    return Array.from(this.newsletters.values()).sort((a, b) => {
      const dateA = new Date(a.createdAt).getTime();
      const dateB = new Date(b.createdAt).getTime();
      return dateB - dateA; // Sort by newest first
    });
  }
  
  // Contact operations
  async createContactSubmission(insertContact: InsertContact): Promise<Contact> {
    const id = this.contactIdCounter++;
    const now = new Date();
    const contact: Contact = { 
      ...insertContact, 
      id, 
      createdAt: now 
    };
    this.contacts.set(id, contact);
    return contact;
  }
  
  async getContactSubmissions(): Promise<Contact[]> {
    return Array.from(this.contacts.values()).sort((a, b) => {
      const dateA = new Date(a.createdAt).getTime();
      const dateB = new Date(b.createdAt).getTime();
      return dateB - dateA; // Sort by newest first
    });
  }
  
  // Initialize sample data
  private initializeData() {
    // Add an admin user
    const adminUser: InsertUser = {
      username: "admin",
      password: "adminpassword", // In a real app, this would be hashed
      email: "admin@example.com",
      isAdmin: true
    };
    this.createUser(adminUser);
    
    // Add categories
    const fitnessCategory: InsertCategory = {
      name: "Fitness",
      slug: "fitness",
      description: "Workout routines, fitness tips, and exercise guidance"
    };
    
    const podcastCategory: InsertCategory = {
      name: "Podcasts",
      slug: "podcasts",
      description: "Podcast recommendations for self-improvement and fitness"
    };
    
    const personalGrowthCategory: InsertCategory = {
      name: "Personal Growth",
      slug: "personal-growth",
      description: "Articles about self-improvement, motivation, and mindfulness"
    };
    
    this.createCategory(fitnessCategory).then(fitness => {
      this.createCategory(podcastCategory).then(podcasts => {
        this.createCategory(personalGrowthCategory).then(growth => {
          // Add posts once categories are created
          this.addSamplePosts(fitness.id, podcasts.id, growth.id);
        });
      });
    });
  }
  
  private async addSamplePosts(fitnessId: number, podcastsId: number, growthId: number) {
    // Sample posts
    const workoutPost: InsertPost = {
      title: "How I Found My Ideal Workout Routine Through YouTube",
      slug: "finding-ideal-workout-routine-youtube",
      content: `<p>For years, I struggled with maintaining a consistent workout routine. I'd sign up for gym memberships that went unused, try workout programs that I'd abandon after a week, and generally felt disconnected from exercise. Everything changed when I discovered the wealth of workout videos available on YouTube.</p>
      
      <h2>The Exploration Process</h2>
      <p>Instead of committing to a single rigid program, I decided to explore different workout styles through various YouTube channels. This approach allowed me to:</p>
      <ul>
        <li>Try different workout types without financial commitment</li>
        <li>Exercise at home on my own schedule</li>
        <li>Match workouts to my energy level each day</li>
        <li>Switch between instructors and styles to prevent boredom</li>
        <li>Discover what truly resonated with my body and interests</li>
      </ul>
      
      <h2>Finding My Favorites</h2>
      <p>Through months of exploration, I discovered that I most enjoy a mix of yoga, pilates, dance workouts, and occasional HIIT sessions. Each fulfills a different need: yoga for flexibility and mindfulness, pilates for core strength, dance for cardio that doesn't feel like work, and HIIT for those days when I want to challenge myself.</p>
      
      <p>I've compiled my favorite channels for each category on my <a href="/fitness">Fitness page</a>, but some standouts include Yoga With Adriene for approachable yoga sessions, MoveWithNicole for challenging pilates workouts, and WorkoutWithSabah for dance workouts that actually make me look forward to exercise.</p>
      
      <h2>The Benefits of Variety</h2>
      <p>This varied approach to fitness has brought several benefits:</p>
      <ul>
        <li>Reduced workout burnout and boredom</li>
        <li>More balanced fitness development (flexibility, strength, cardio)</li>
        <li>Better adherence to regular exercise</li>
        <li>Greater enjoyment of movement</li>
        <li>Improved body awareness from trying different modalities</li>
      </ul>
      
      <p>What started as random YouTube searches has evolved into a sustainable fitness lifestyle. I'm not perfect—some weeks I exercise more than others—but I no longer view fitness as a chore or obligation.</p>
      
      <p>If you're struggling to find a workout routine that sticks, I encourage you to explore the variety available on YouTube. The perfect workout might not be a single program but rather a mix of different styles that keep you engaged and excited to move your body.</p>`,
      excerpt: "How exploring diverse YouTube workout videos helped me create a sustainable and enjoyable fitness routine that actually sticks...",
      coverImage: "https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      authorId: 1,
      categoryId: fitnessId
    };
    
    const podcastPost: InsertPost = {
      title: "5 Podcasts That Changed My Perspective",
      slug: "5-podcasts-that-changed-my-perspective",
      content: `<p>Podcasts have become my favorite way to learn and grow while doing otherwise mundane tasks like commuting or cleaning. These five podcasts specifically have had a profound impact on how I view health, fitness, and personal development.</p>
      
      <h2>1. The Model Health Show with Shawn Stevenson</h2>
      <p>This podcast completely changed my understanding of nutrition and sleep hygiene. Shawn breaks down complex scientific concepts into digestible information and interviews world-class experts in health and wellness. The episode on circadian rhythms actually led me to restructure my entire daily routine for better sleep and energy.</p>
      
      <h2>2. The Tim Ferriss Show</h2>
      <p>Tim interviews top performers from diverse fields to deconstruct their habits, routines, and mindsets. His thoughtful questioning style extracts practical wisdom you can apply to your own life. The episode with Dr. Peter Attia on longevity had me rethinking my approach to long-term health.</p>
      
      <h2>3. Ten Percent Happier with Dan Harris</h2>
      <p>After experiencing a panic attack on live television, ABC news anchor Dan Harris turned to meditation. His podcast explores meditation and mindfulness with a healthy dose of skepticism that makes it approachable for beginners. The episode "Meditation for Fidgety Skeptics" helped me finally establish a consistent meditation practice.</p>
      
      <h2>4. Feel Better, Live More with Dr. Rangan Chatterjee</h2>
      <p>Dr. Chatterjee takes a holistic approach to health, examining how lifestyle factors like sleep, nutrition, movement, and stress management work together. His conversation about the connection between gut health and mental wellbeing led me to make significant dietary changes with noticeable benefits.</p>
      
      <h2>5. The Rich Roll Podcast</h2>
      <p>As an ultra-endurance athlete and former lawyer, Rich brings a unique perspective to conversations about physical and mental transformation. His interviews go deep and often run several hours, allowing for nuanced discussions. His episode with sleep expert Matthew Walker convinced me to prioritize sleep as the foundation of my health routine.</p>
      
      <h2>The Impact</h2>
      <p>These podcasts have:
      <ul>
        <li>Equipped me with evidence-based health information</li>
        <li>Introduced me to experts I might never have discovered otherwise</li>
        <li>Provided practical strategies I've implemented in my daily life</li>
        <li>Expanded my perspective beyond conventional wisdom</li>
        <li>Kept me company during countless workouts, commutes, and household chores</li>
      </ul>
      
      <p>I'd love to hear which podcasts have influenced your health journey. Share your recommendations in the comments below!</p>`,
      excerpt: "These thought-provoking podcasts challenged my thinking and opened my mind to new ideas about personal growth and wellbeing...",
      coverImage: "https://images.unsplash.com/photo-1542435503-956c469947f6?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      authorId: 1,
      categoryId: podcastsId
    };
    
    const mindfulnessPost: InsertPost = {
      title: "Mindfulness Practices That Changed My Daily Life",
      slug: "mindfulness-practices-changed-daily-life",
      content: `<p>Two years ago, if someone had told me that sitting quietly for 10 minutes each morning would transform my entire day, I would have been skeptical. Now, I can't imagine starting my day any other way. Here's how incorporating simple mindfulness practices has changed my life for the better.</p>
      
      <h2>Morning Meditation</h2>
      <p>I begin each day with a 10-minute guided meditation. I use apps like Calm or Headspace to help me stay focused. This practice helps me set an intention for the day and creates a moment of calm before the inevitable chaos begins. I've noticed that on days when I skip this practice, I'm more reactive to stress and less focused on my tasks.</p>
      
      <h2>Mindful Eating</h2>
      <p>I used to eat breakfast while checking emails, lunch at my desk, and dinner while watching TV. Now, I try to eat at least one meal per day without any distractions. I focus on the flavors, textures, and sensations of eating. This has not only improved my digestion but has made meals more enjoyable and satisfying.</p>
      
      <h2>Three Mindful Breaths</h2>
      <p>Throughout the day, I take "breath breaks" where I pause whatever I'm doing and take three slow, deep breaths. I often set reminders on my phone or associate this practice with regular activities like before checking email or before entering a meeting. These micro-moments of mindfulness help reset my nervous system and improve my focus.</p>
      
      <h2>Body Scan Before Sleep</h2>
      <p>Instead of scrolling through social media before bed, I now do a brief body scan meditation. Starting from my toes and moving up to my head, I mentally scan each part of my body, noticing any tension and consciously relaxing each area. This practice has significantly improved my sleep quality and helps create a buffer between the day's activities and rest.</p>
      
      <h2>Gratitude Practice</h2>
      <p>Each evening, I write down three things I'm grateful for from the day. They can be as simple as "the perfect cup of coffee" or as significant as "a meaningful conversation with a friend." This practice has trained my mind to look for the positive throughout the day, even during challenging times.</p>
      
      <h2>The Results</h2>
      <p>Since incorporating these practices into my daily routine, I've experienced:
      <ul>
        <li>Reduced anxiety and stress</li>
        <li>Improved focus and productivity</li>
        <li>Better sleep quality</li>
        <li>More meaningful connections with others</li>
        <li>Greater resilience during challenging times</li>
      </ul>
      
      <p>The beauty of mindfulness is that it doesn't require any special equipment or significant time investment. Even a few minutes of mindful awareness can make a difference in how you experience your day.</p>
      
      <p>What mindfulness practices have worked for you? I'd love to hear about your experiences in the comments.</p>`,
      excerpt: "How simple mindfulness practices transformed my daily routine and improved my overall wellbeing...",
      coverImage: "https://images.unsplash.com/photo-1488190211105-8b0e65b80b4e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      authorId: 1,
      categoryId: growthId
    };
    
    // Create posts
    const post1 = await this.createPost(workoutPost);
    const post2 = await this.createPost(podcastPost);
    const post3 = await this.createPost(mindfulnessPost);
    
    // Add comments to the first post
    const comment1: InsertComment = {
      name: "Jane Smith",
      email: "jane.smith@example.com",
      content: "I've been trying Yoga With Adriene based on your recommendation and it's amazing! Her approach is so accessible and I finally feel like I'm making progress with yoga. Thanks for sharing these resources!",
      postId: post1.id
    };
    
    const comment2: InsertComment = {
      name: "Mike Kennedy",
      email: "mike.kennedy@example.com",
      content: "Which channels would you recommend for beginners with limited flexibility? I want to start a home workout routine but feel intimidated by some of the advanced content out there.",
      postId: post1.id
    };
    
    const comment3: InsertComment = {
      name: "Alex Rodriguez",
      email: "alex.rodriguez@example.com",
      content: "The variety approach is key! I've been following MadFit for HIIT and Blogilates for strength training, and the combination keeps me motivated. Have you tried any of Caroline Girvan's workouts on YouTube?",
      postId: post1.id
    };
    
    await this.createComment(comment1);
    await this.createComment(comment2);
    await this.createComment(comment3);
  }
}

export const storage = new MemStorage();
